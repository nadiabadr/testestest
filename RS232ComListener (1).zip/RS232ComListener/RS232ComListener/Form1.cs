﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RS232ComListener
{
    public partial class Form1 : Form
    {
        private System.IO.Ports.SerialPort serialPortRead;
        private static string RxString = "";

        public Form1()
        {
            InitializeComponent();
            this.components = new System.ComponentModel.Container();
            this.serialPortRead = new System.IO.Ports.SerialPort(this.components);
            this.serialPortRead.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPortRead_DataReceived);
            cbHandShake.DataSource = GetHandShakes();
            cbStopBits.DataSource = GetStopBitss();
            cbParity.DataSource = GetParity();
            
        }
        public List<string> GetHandShakes()
        {
            List<string> ss = new List<string>();
            foreach (string s in Enum.GetNames(typeof(Handshake)))
            {
                ss.Add(s);
            }
            return ss;
        }
        public List<string> GetStopBitss()
        {
            List<string> ss = new List<string>();
            foreach (string s in Enum.GetNames(typeof(System.IO.Ports.StopBits)))
            {
                ss.Add(s);
            }
            return ss;
        }
        public List<string> GetParity()
        {
            List<string> ss = new List<string>();
            foreach (string s in Enum.GetNames(typeof(System.IO.Ports.Parity)))
            {
                ss.Add(s);
            }
            return ss;
        }
        private void serialPortRead_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                RxString = serialPortRead.ReadExisting();
                this.Invoke(new EventHandler(DisplayText));
            }
            catch (System.TimeoutException) { }
        }

        private void DisplayText(object sender, EventArgs e)
        {
            rTxtReceived.AppendText(RxString);
        }
        
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {

                // make sure port isn't open	
                if (!serialPortRead.IsOpen)
                {
                    // 
                    // serialPort
                    //
                    serialPortRead.BaudRate = int.Parse(txtBaud.Text);
                    serialPortRead.PortName = txtCOM.Text;
                    serialPortRead.Parity = (System.IO.Ports.Parity)Enum.Parse(typeof(System.IO.Ports.Parity), cbParity.SelectedValue.ToString(), true); // = System.IO.Ports.Parity.Even;

                    serialPortRead.RtsEnable = ckRtsEnable.Checked?true:false;
                    serialPortRead.DiscardNull = ckDiscardNull.Checked ? true : false;
                    serialPortRead.DtrEnable = ckDtrEnable.Checked ? true : false;

                    if(!string.IsNullOrEmpty(txtCharacterLength.Text))
                    serialPortRead.DataBits = int.Parse(txtCharacterLength.Text);

                    if(!string.IsNullOrEmpty(cbHandShake.SelectedValue.ToString()))
                    serialPortRead.Handshake = (Handshake)Enum.Parse(typeof(Handshake), cbHandShake.SelectedValue.ToString(), true);
                    if (!string.IsNullOrEmpty(cbStopBits.SelectedValue.ToString()))
                        serialPortRead.StopBits = (System.IO.Ports.StopBits)Enum.Parse(typeof(StopBits), cbStopBits.SelectedValue.ToString(), true);
                    serialPortRead.ReadTimeout = 500;
                    serialPortRead.WriteTimeout = 500;
                    // set status
                    rTxtReceived.Text = serialPortRead.PortName + " Ready!";
                    //open serial port 
                    serialPortRead.Open();
                    serialPortRead.Write(txtCommand.Text);

                }
                else
                {
                    rTxtReceived.Text = "Port isn't openned";
                    serialPortRead.Write(txtCommand.Text);
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnListner_Click(object sender, EventArgs e)
        {
            try
            {
                // make sure port isn't open	
                if (!serialPortRead.IsOpen)
                {
                    // 
                    // serialPort
                    // 
                    serialPortRead.BaudRate = int.Parse(txtBaud.Text);
                    serialPortRead.PortName = txtCOM.Text;

                    serialPortRead.Parity = System.IO.Ports.Parity.Even;
                    serialPortRead.Handshake = System.IO.Ports.Handshake.XOnXOff;
                    serialPortRead.StopBits = System.IO.Ports.StopBits.One;
                    serialPortRead.ReadTimeout = 500;
                    serialPortRead.WriteTimeout = 500;
                    // set status
                    rTxtReceived.AppendText(serialPortRead.PortName + " Ready!");
                    //open serial port 
                    serialPortRead.Open();
                    // prevent reinitiation 
                    btnListner.Enabled = false;
                }
                else
                    rTxtReceived.Text = "Port isn't openned";
            }
            catch (UnauthorizedAccessException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            serialPortRead.Close();
        }
    }
}
