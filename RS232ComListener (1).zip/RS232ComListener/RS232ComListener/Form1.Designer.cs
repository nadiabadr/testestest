﻿namespace RS232ComListener
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCOM = new System.Windows.Forms.TextBox();
            this.lblCOM = new System.Windows.Forms.Label();
            this.lblBaud = new System.Windows.Forms.Label();
            this.txtBaud = new System.Windows.Forms.TextBox();
            this.lblFlowControl = new System.Windows.Forms.Label();
            this.lblCharacterLength = new System.Windows.Forms.Label();
            this.txtCharacterLength = new System.Windows.Forms.TextBox();
            this.lblParity = new System.Windows.Forms.Label();
            this.btnListner = new System.Windows.Forms.Button();
            this.lblCMD = new System.Windows.Forms.Label();
            this.txtCommand = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.rTxtReceived = new System.Windows.Forms.RichTextBox();
            this.lblReceived = new System.Windows.Forms.Label();
            this.cbHandShake = new System.Windows.Forms.ComboBox();
            this.ckRtsEnable = new System.Windows.Forms.CheckBox();
            this.cbStopBits = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbParity = new System.Windows.Forms.ComboBox();
            this.ckDiscardNull = new System.Windows.Forms.CheckBox();
            this.ckDtrEnable = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // txtCOM
            // 
            this.txtCOM.Location = new System.Drawing.Point(630, 157);
            this.txtCOM.Name = "txtCOM";
            this.txtCOM.Size = new System.Drawing.Size(100, 20);
            this.txtCOM.TabIndex = 0;
            this.txtCOM.Text = "COM7";
            // 
            // lblCOM
            // 
            this.lblCOM.AutoSize = true;
            this.lblCOM.Location = new System.Drawing.Point(585, 160);
            this.lblCOM.Name = "lblCOM";
            this.lblCOM.Size = new System.Drawing.Size(37, 13);
            this.lblCOM.TabIndex = 1;
            this.lblCOM.Text = "COM :";
            // 
            // lblBaud
            // 
            this.lblBaud.AutoSize = true;
            this.lblBaud.Location = new System.Drawing.Point(557, 25);
            this.lblBaud.Name = "lblBaud";
            this.lblBaud.Size = new System.Drawing.Size(61, 13);
            this.lblBaud.TabIndex = 3;
            this.lblBaud.Text = "BaudRate :";
            // 
            // txtBaud
            // 
            this.txtBaud.Location = new System.Drawing.Point(630, 22);
            this.txtBaud.Name = "txtBaud";
            this.txtBaud.Size = new System.Drawing.Size(100, 20);
            this.txtBaud.TabIndex = 2;
            this.txtBaud.Text = "9600";
            // 
            // lblFlowControl
            // 
            this.lblFlowControl.AutoSize = true;
            this.lblFlowControl.Location = new System.Drawing.Point(557, 103);
            this.lblFlowControl.Name = "lblFlowControl";
            this.lblFlowControl.Size = new System.Drawing.Size(68, 13);
            this.lblFlowControl.TabIndex = 5;
            this.lblFlowControl.Text = "FlowControl :";
            // 
            // lblCharacterLength
            // 
            this.lblCharacterLength.AutoSize = true;
            this.lblCharacterLength.Location = new System.Drawing.Point(532, 77);
            this.lblCharacterLength.Name = "lblCharacterLength";
            this.lblCharacterLength.Size = new System.Drawing.Size(92, 13);
            this.lblCharacterLength.TabIndex = 7;
            this.lblCharacterLength.Text = "CharacterLength :";
            // 
            // txtCharacterLength
            // 
            this.txtCharacterLength.Location = new System.Drawing.Point(630, 74);
            this.txtCharacterLength.Name = "txtCharacterLength";
            this.txtCharacterLength.Size = new System.Drawing.Size(100, 20);
            this.txtCharacterLength.TabIndex = 6;
            this.txtCharacterLength.Text = "7";
            // 
            // lblParity
            // 
            this.lblParity.AutoSize = true;
            this.lblParity.Location = new System.Drawing.Point(585, 48);
            this.lblParity.Name = "lblParity";
            this.lblParity.Size = new System.Drawing.Size(39, 13);
            this.lblParity.TabIndex = 9;
            this.lblParity.Text = "Parity :";
            // 
            // btnListner
            // 
            this.btnListner.Location = new System.Drawing.Point(606, 254);
            this.btnListner.Name = "btnListner";
            this.btnListner.Size = new System.Drawing.Size(124, 23);
            this.btnListner.TabIndex = 10;
            this.btnListner.Text = "Activate Port Listner";
            this.btnListner.UseVisualStyleBackColor = true;
            this.btnListner.Click += new System.EventHandler(this.btnListner_Click);
            // 
            // lblCMD
            // 
            this.lblCMD.AutoSize = true;
            this.lblCMD.Location = new System.Drawing.Point(357, 14);
            this.lblCMD.Name = "lblCMD";
            this.lblCMD.Size = new System.Drawing.Size(60, 13);
            this.lblCMD.TabIndex = 14;
            this.lblCMD.Text = "Command :";
            // 
            // txtCommand
            // 
            this.txtCommand.Location = new System.Drawing.Point(427, 11);
            this.txtCommand.Name = "txtCommand";
            this.txtCommand.Size = new System.Drawing.Size(100, 20);
            this.txtCommand.TabIndex = 13;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(451, 38);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 15;
            this.btnSend.Text = "Send Command";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // rTxtReceived
            // 
            this.rTxtReceived.Location = new System.Drawing.Point(25, 91);
            this.rTxtReceived.Name = "rTxtReceived";
            this.rTxtReceived.Size = new System.Drawing.Size(501, 297);
            this.rTxtReceived.TabIndex = 16;
            this.rTxtReceived.Text = "";
            // 
            // lblReceived
            // 
            this.lblReceived.AutoSize = true;
            this.lblReceived.Location = new System.Drawing.Point(25, 72);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Size = new System.Drawing.Size(59, 13);
            this.lblReceived.TabIndex = 17;
            this.lblReceived.Text = "Received :";
            // 
            // cbHandShake
            // 
            this.cbHandShake.FormattingEnabled = true;
            this.cbHandShake.Location = new System.Drawing.Point(630, 99);
            this.cbHandShake.Name = "cbHandShake";
            this.cbHandShake.Size = new System.Drawing.Size(100, 21);
            this.cbHandShake.TabIndex = 18;
            // 
            // ckRtsEnable
            // 
            this.ckRtsEnable.AutoSize = true;
            this.ckRtsEnable.Location = new System.Drawing.Point(650, 183);
            this.ckRtsEnable.Name = "ckRtsEnable";
            this.ckRtsEnable.Size = new System.Drawing.Size(75, 17);
            this.ckRtsEnable.TabIndex = 19;
            this.ckRtsEnable.Text = "RtsEnable";
            this.ckRtsEnable.UseVisualStyleBackColor = true;
            // 
            // cbStopBits
            // 
            this.cbStopBits.FormattingEnabled = true;
            this.cbStopBits.Location = new System.Drawing.Point(630, 126);
            this.cbStopBits.Name = "cbStopBits";
            this.cbStopBits.Size = new System.Drawing.Size(100, 21);
            this.cbStopBits.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(557, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Stop Bits :";
            // 
            // cbParity
            // 
            this.cbParity.FormattingEnabled = true;
            this.cbParity.Location = new System.Drawing.Point(630, 48);
            this.cbParity.Name = "cbParity";
            this.cbParity.Size = new System.Drawing.Size(100, 21);
            this.cbParity.TabIndex = 22;
            // 
            // ckDiscardNull
            // 
            this.ckDiscardNull.AutoSize = true;
            this.ckDiscardNull.Location = new System.Drawing.Point(650, 206);
            this.ckDiscardNull.Name = "ckDiscardNull";
            this.ckDiscardNull.Size = new System.Drawing.Size(80, 17);
            this.ckDiscardNull.TabIndex = 23;
            this.ckDiscardNull.Text = "DiscardNull";
            this.ckDiscardNull.UseVisualStyleBackColor = true;
            // 
            // ckDtrEnable
            // 
            this.ckDtrEnable.AutoSize = true;
            this.ckDtrEnable.Location = new System.Drawing.Point(650, 229);
            this.ckDtrEnable.Name = "ckDtrEnable";
            this.ckDtrEnable.Size = new System.Drawing.Size(73, 17);
            this.ckDtrEnable.TabIndex = 24;
            this.ckDtrEnable.Text = "DtrEnable";
            this.ckDtrEnable.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 403);
            this.Controls.Add(this.ckDtrEnable);
            this.Controls.Add(this.ckDiscardNull);
            this.Controls.Add(this.cbParity);
            this.Controls.Add(this.cbStopBits);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ckRtsEnable);
            this.Controls.Add(this.cbHandShake);
            this.Controls.Add(this.lblReceived);
            this.Controls.Add(this.rTxtReceived);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.lblCMD);
            this.Controls.Add(this.txtCommand);
            this.Controls.Add(this.btnListner);
            this.Controls.Add(this.lblParity);
            this.Controls.Add(this.lblCharacterLength);
            this.Controls.Add(this.txtCharacterLength);
            this.Controls.Add(this.lblFlowControl);
            this.Controls.Add(this.lblBaud);
            this.Controls.Add(this.txtBaud);
            this.Controls.Add(this.lblCOM);
            this.Controls.Add(this.txtCOM);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCOM;
        private System.Windows.Forms.Label lblCOM;
        private System.Windows.Forms.Label lblBaud;
        private System.Windows.Forms.TextBox txtBaud;
        private System.Windows.Forms.Label lblFlowControl;
        private System.Windows.Forms.Label lblCharacterLength;
        private System.Windows.Forms.TextBox txtCharacterLength;
        private System.Windows.Forms.Label lblParity;
        private System.Windows.Forms.Button btnListner;
        private System.Windows.Forms.Label lblCMD;
        private System.Windows.Forms.TextBox txtCommand;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox rTxtReceived;
        private System.Windows.Forms.Label lblReceived;
        private System.Windows.Forms.ComboBox cbHandShake;
        private System.Windows.Forms.CheckBox ckRtsEnable;
        private System.Windows.Forms.ComboBox cbStopBits;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbParity;
        private System.Windows.Forms.CheckBox ckDiscardNull;
        private System.Windows.Forms.CheckBox ckDtrEnable;
    }
}

